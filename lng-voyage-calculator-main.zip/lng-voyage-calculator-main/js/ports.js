/* ============================================================
   LNG Voyage Calculator — Βάση λιμένων
   Συντεταγμένες & ζώνες ώρας (UTC offset, χειμερινή ώρα).
   Οι αποστάσεις είναι great-circle — χρησιμοποιήστε τη
   χειροκίνητη απόσταση (sea distance) για ακρίβεια πλόου.
   ============================================================ */

const PORTS = [
  // — Εξαγωγικοί (Load) τερματικοί σταθμοί LNG —
  { name: "Ras Laffan",              country: "Κατάρ",        lat: 25.92,  lon: 51.55,  tz: 3,     type: "load" },
  { name: "Ras Tanura",              country: "Σαουδ. Αραβία", lat: 26.65,  lon: 50.15,  tz: 3,     type: "load" },
  { name: "Basrah (Basrah LNG)",     country: "Ιράκ",          lat: 30.02,  lon: 47.95,  tz: 3,     type: "load" },
  { name: "Aden",                    country: "Υεμένη",        lat: 12.78,  lon: 45.03,  tz: 3,     type: "load" },
  { name: "Damietta",                country: "Αίγυπτος",      lat: 31.42,  lon: 31.82,  tz: 2,     type: "load" },
  { name: "Idku (Egypt LNG)",        country: "Αίγυπτος",      lat: 31.42,  lon: 30.35,  tz: 2,     type: "load" },
  { name: "Ain Sokhna",              country: "Αίγυπτος",      lat: 29.60,  lon: 32.35,  tz: 2,     type: "load" },
  { name: "Arzew",                   country: "Αλγερία",       lat: 35.85,  lon: -0.32,  tz: 1,     type: "load" },
  { name: "Skikda",                  country: "Αλγερία",       lat: 36.88,  lon: 6.91,   tz: 1,     type: "load" },
  { name: "Bonny Island (NLNG)",     country: "Νιγηρία",       lat: 4.42,   lon: 7.15,   tz: 1,     type: "load" },
  { name: "Punta Europa (EG LNG)",   country: "Ισ. Guinea",    lat: 3.75,   lon: 8.78,   tz: 1,     type: "load" },
  { name: "Soyo (Angola LNG)",       country: "Αγκόλα",        lat: -6.13,  lon: 12.37,  tz: 1,     type: "load" },
  { name: "Point Fortin (Atlantic)", country: "Τρινιντάντ",    lat: 10.30,  lon: -61.85, tz: -4,    type: "load" },
  { name: "Sabine Pass",             country: "ΗΠΑ (Τέξας)",   lat: 29.75,  lon: -93.87, tz: -6,    type: "load" },
  { name: "Corpus Christi",          country: "ΗΠΑ (Τέξας)",   lat: 27.80,  lon: -97.20, tz: -6,    type: "load" },
  { name: "Cameron LNG (Hackberry)", country: "ΗΠΑ (Λουιζιάνα)", lat: 29.98, lon: -93.30, tz: -6,  type: "load" },
  { name: "Freeport",                country: "ΗΠΑ (Τέξας)",   lat: 28.93,  lon: -95.28, tz: -6,    type: "load" },
  { name: "Elba Island (Savannah)",  country: "ΗΠΑ (Τζόρτζια)", lat: 32.08, lon: -81.09, tz: -5,    type: "load" },
  { name: "Cove Point",              country: "ΗΠΑ (Μέριλαντ)", lat: 38.89, lon: -76.39, tz: -5,    type: "load" },
  { name: "Altamira",                country: "Μεξικό",        lat: 22.40,  lon: -97.93, tz: -6,    type: "load" },
  { name: "Manzanillo (ECA LNG)",    country: "Μεξικό",        lat: 19.05,  lon: -104.30, tz: -6,   type: "load" },
  { name: "Pampa Melchorita (Peru LNG)", country: "Περού",    lat: -13.35, lon: -76.24, tz: -5,    type: "load" },
  { name: "Bintulu (MLNG)",          country: "Μαλαισία",      lat: 3.00,   lon: 113.05, tz: 8,     type: "load" },
  { name: "Bontang",                 country: "Ινδονησία",     lat: 0.13,   lon: 117.50, tz: 8,     type: "load" },
  { name: "Tangguh (Berau Bay)",     country: "Ινδονησία",     lat: -2.42,  lon: 122.50, tz: 8,     type: "load" },
  { name: "Hammerfest (Snohvit)",    country: "Νορβηγία",     lat: 70.68,  lon: 23.68,  tz: 1,     type: "load" },
  { name: "Prigorodnoye (Sakhalin)", country: "Ρωσία",        lat: 46.65,  lon: 142.40, tz: 11,    type: "load" },
  { name: "Barrow Island (Gorgon)",  country: "Αυστραλία",    lat: -21.00, lon: 115.30, tz: 8,     type: "load" },
  { name: "Onslow (Wheatstone)",     country: "Αυστραλία",    lat: -21.65, lon: 115.00, tz: 8,     type: "load" },
  { name: "Karratha (North West Shelf / Pluto)", country: "Αυστραλία", lat: -20.73, lon: 116.00, tz: 8, type: "load" },
  { name: "Dampier",                 country: "Αυστραλία",    lat: -20.60, lon: 116.70, tz: 8,     type: "load" },
  { name: "Gladstone (QCLNG / APLNG / GLNG)", country: "Αυστραλία", lat: -23.85, lon: 151.25, tz: 10, type: "load" },
  { name: "Darwin / Ichthys",        country: "Αυστραλία",    lat: -12.20, lon: 130.80, tz: 9.5,   type: "load" },
  { name: "Mina Al-Ahmadi",          country: "Κουβέιτ",      lat: 29.10,  lon: 48.15,  tz: 3,     type: "load" },
  { name: "Ruwais",                  country: "ΗΑΕ",          lat: 24.00,  lon: 54.00,  tz: 4,     type: "load" },

  // — Εισαγωγικοί (Discharge) τερματικοί σταθμοί LNG —
  { name: "Revithoussa",             country: "Ελλάδα",       lat: 37.90,  lon: 23.10,  tz: 2,     type: "discharge" },
  { name: "Aliaga",                  country: "Τουρκία",      lat: 38.72,  lon: 26.95,  tz: 3,     type: "discharge" },
  { name: "Marmara Ereğlisi",        country: "Τουρκία",      lat: 41.00,  lon: 28.25,  tz: 3,     type: "discharge" },
  { name: "Dörtyol",                 country: "Τουρκία",      lat: 36.85,  lon: 36.15,  tz: 3,     type: "discharge" },
  { name: "Zeebrugge",               country: "Βέλγιο",       lat: 51.35,  lon: 3.20,   tz: 1,     type: "discharge" },
  { name: "Dunkerque",               country: "Γαλλία",       lat: 51.05,  lon: 2.37,   tz: 1,     type: "discharge" },
  { name: "Montoir-de-Bretagne",     country: "Γαλλία",       lat: 47.30,  lon: -2.16,  tz: 1,     type: "discharge" },
  { name: "Fos Cavaou / Fos Tonkin", country: "Γαλλία",       lat: 43.40,  lon: 4.95,   tz: 1,     type: "discharge" },
  { name: "Barcelona",               country: "Ισπανία",      lat: 41.35,  lon: 2.15,   tz: 1,     type: "discharge" },
  { name: "Sagunto",                 country: "Ισπανία",      lat: 39.65,  lon: -0.22,  tz: 1,     type: "discharge" },
  { name: "Bilbao",                  country: "Ισπανία",      lat: 43.35,  lon: -3.05,  tz: 1,     type: "discharge" },
  { name: "Cartagena",               country: "Ισπανία",      lat: 37.60,  lon: -1.00,  tz: 1,     type: "discharge" },
  { name: "Huelva",                  country: "Ισπανία",      lat: 37.20,  lon: -6.80,  tz: 1,     type: "discharge" },
  { name: "Mugardes (Ferrol)",       country: "Ισπανία",      lat: 43.45,  lon: -8.25,  tz: 1,     type: "discharge" },
  { name: "Sines",                   country: "Πορτογαλία",   lat: 37.95,  lon: -8.87,  tz: 0,     type: "discharge" },
  { name: "Panigaglia",              country: "Ιταλία",       lat: 44.10,  lon: 9.83,   tz: 1,     type: "discharge" },
  { name: "Livorno (OLT Toscana)",   country: "Ιταλία",       lat: 43.50,  lon: 10.20,  tz: 1,     type: "discharge" },
  { name: "South Hook (Milford Haven)", country: "Ουαλία, ΗΒ", lat: 51.73, lon: -5.05,  tz: 0,     type: "discharge" },
  { name: "Dragon (Milford Haven)",  country: "Ουαλία, ΗΒ",   lat: 51.73,  lon: -5.03,  tz: 0,     type: "discharge" },
  { name: "Isle of Grain",           country: "Αγγλία, ΗΒ",   lat: 51.44,  lon: 0.70,   tz: 0,     type: "discharge" },
  { name: "Gate Terminal (Rotterdam)", country: "Ολλανδία",   lat: 51.95,  lon: 4.15,   tz: 1,     type: "discharge" },
  { name: "Eemshaven / Gateway",     country: "Ολλανδία",     lat: 53.40,  lon: 6.80,   tz: 1,     type: "discharge" },
  { name: "Świnoujście",             country: "Πολωνία",      lat: 53.90,  lon: 14.25,  tz: 1,     type: "discharge" },
  { name: "Klaipėda",                country: "Λιθουανία",    lat: 55.70,  lon: 21.10,  tz: 2,     type: "discharge" },
  { name: "Nynäshamn",               country: "Σουηδία",      lat: 58.90,  lon: 17.95,  tz: 1,     type: "discharge" },
  { name: "Brunsbüttel",             country: "Γερμανία",     lat: 53.90,  lon: 9.15,   tz: 1,     type: "discharge" },
  { name: "Wilhelmshaven",           country: "Γερμανία",     lat: 53.60,  lon: 8.10,   tz: 1,     type: "discharge" },
  { name: "Krk (Omišalj)",           country: "Κροατία",      lat: 45.15,  lon: 14.55,  tz: 1,     type: "discharge" },
  { name: "Delimara",                country: "Μάλτα",        lat: 35.83,  lon: 14.55,  tz: 1,     type: "discharge" },
  { name: "Vasiliko",                country: "Κύπρος",       lat: 34.72,  lon: 33.30,  tz: 2,     type: "discharge" },
  { name: "Yokohama (Negishi)",     country: "Ιαπωνία",       lat: 35.45,  lon: 139.65, tz: 9,     type: "discharge" },
  { name: "Sodegaura (Τόκιο)",       country: "Ιαπωνία",      lat: 35.50,  lon: 139.90, tz: 9,     type: "discharge" },
  { name: "Chita (Ναγκόγια)",        country: "Ιαπωνία",      lat: 35.00,  lon: 136.85, tz: 9,     type: "discharge" },
  { name: "Senboku (Οσάκα)",         country: "Ιαπωνία",      lat: 34.60,  lon: 135.40, tz: 9,     type: "discharge" },
  { name: "Himeji",                  country: "Ιαπωνία",      lat: 34.80,  lon: 134.70, tz: 9,     type: "discharge" },
  { name: "Tobata (Κιτακιούσου)",    country: "Ιαπωνία",      lat: 33.90,  lon: 130.80, tz: 9,     type: "discharge" },
  { name: "Νiigata",                 country: "Ιαπωνία",      lat: 37.95,  lon: 139.05, tz: 9,     type: "discharge" },
  { name: "Pyeongtaek",              country: "Ν. Κορέα",     lat: 37.00,  lon: 126.85, tz: 9,     type: "discharge" },
  { name: "Tongyeong",               country: "Ν. Κορέα",     lat: 34.85,  lon: 128.45, tz: 9,     type: "discharge" },
  { name: "Rudong",                  country: "Κίνα",         lat: 32.30,  lon: 121.40, tz: 8,     type: "discharge" },
  { name: "Dalian",                  country: "Κίνα",         lat: 38.95,  lon: 121.65, tz: 8,     type: "discharge" },
  { name: "Shenzhen (Diefu)",        country: "Κίνα",         lat: 22.55,  lon: 113.90, tz: 8,     type: "discharge" },
  { name: "Taichung",                country: "Ταϊβάν",       lat: 24.25,  lon: 120.45, tz: 8,     type: "discharge" },
  { name: "Map Ta Phut",             country: "Ταϊλάνδη",     lat: 12.70,  lon: 101.20, tz: 7,     type: "discharge" },
  { name: "Pengerang",               country: "Μαλαισία",     lat: 1.35,   lon: 104.10, tz: 8,     type: "discharge" },
  { name: "Thi Vai",                 country: "Βιετνάμ",      lat: 10.55,  lon: 107.00, tz: 7,     type: "discharge" },
  { name: "Dahej",                   country: "Ινδία",        lat: 21.70,  lon: 72.60,  tz: 5.5,   type: "discharge" },
  { name: "Hazira",                  country: "Ινδία",        lat: 21.10,  lon: 72.70,  tz: 5.5,   type: "discharge" },
  { name: "Kochi",                   country: "Ινδία",        lat: 9.90,   lon: 76.30,  tz: 5.5,   type: "discharge" },
  { name: "Ennore",                  country: "Ινδία",        lat: 13.25,  lon: 80.30,  tz: 5.5,   type: "discharge" },
  { name: "Port Qasim (Karachi)",    country: "Πακιστάν",     lat: 24.77,  lon: 67.34,  tz: 5,     type: "discharge" },
  { name: "Moheshkhali",             country: "Μπανγκλαντές", lat: 21.50,  lon: 91.90,  tz: 6,     type: "discharge" },
  { name: "Pecém",                   country: "Βραζιλία",     lat: -3.55,  lon: -38.80, tz: -3,    type: "discharge" },
  { name: "Guanabara (Rio)",         country: "Βραζιλία",     lat: -22.85, lon: -43.15, tz: -3,    type: "discharge" },
  { name: "Quintero",                country: "Χιλή",         lat: -32.78, lon: -71.50, tz: -4,    type: "discharge" },
  { name: "Mejillones",              country: "Χιλή",         lat: -23.10, lon: -70.50, tz: -4,    type: "discharge" },
  { name: "Bahía Blanca",            country: "Αργεντινή",    lat: -38.80, lon: -62.25, tz: -3,    type: "discharge" },
  { name: "Punta Caucedo",           country: "Δομινικανή Δημ.", lat: 18.45, lon: -69.60, tz: -4,  type: "discharge" },
  { name: "Ponce",                   country: "Πουέρτο Ρίκο", lat: 17.97,  lon: -66.65, tz: -4,    type: "discharge" },
  { name: "Hadera",                  country: "Ισραήλ",       lat: 32.55,  lon: 34.90,  tz: 2,     type: "discharge" },

  // — Λιμένες bunkering / υποστήριξης —
  { name: "Πειραιάς",                 country: "Ελλάδα",       lat: 37.94,  lon: 23.63,  tz: 2,     type: "bunker" },
  { name: "Gibraltar",               country: "Γιβραλτάρ",    lat: 36.14,  lon: -5.35,  tz: 1,     type: "bunker" },
  { name: "Fujairah",                country: "ΗΑΕ",          lat: 25.10,  lon: 56.35,  tz: 4,     type: "bunker" },
  { name: "Las Palmas",              country: "Ισπανία",      lat: 28.10,  lon: -15.40, tz: 0,     type: "bunker" },
  { name: "Singapore",               country: "Σιγκαπούρη",   lat: 1.26,   lon: 103.80, tz: 8,     type: "bunker" },

  // — Λιμένες διωρύγων —
  { name: "Port Said",            country: "Σουέζ", lat: 31.25, lon: 32.30, tz: 2,   type: "canal" },
  { name: "Suez",                 country: "Σουέζ", lat: 29.97, lon: 32.55, tz: 2,   type: "canal" },
  { name: "Cristóbal (Atlantic)",    country: "Παναμάς",      lat: 9.36,   lon: -79.90, tz: -5,    type: "canal" },
  { name: "Balboa (Pacific)",        country: "Παναμάς",      lat: 8.94,   lon: -79.56, tz: -5,    type: "canal" },
];

/* Διώρυγες: ζεύγη λιμένων, απόσταση διέλευσης (nm) και ώρες transit */
const CANALS = [
  { key: "suez",   a: "Port Said", b: "Suez",            nm: 90, label: "Διώρυγα Σουέζ" },
  { key: "panama", a: "Cristóbal (Atlantic)", b: "Balboa (Pacific)", nm: 44, label: "Διώρυγα Παναμά" },
];

/* Επιστρέφει τα δεδομένα διώρυγας αν το σκέλος ενώνει το αντίστοιχο ζεύγος λιμένων */
function legCanal(fromIdx, toIdx) {
  for (const c of CANALS) {
    const ai = PORTS.findIndex((p) => p.name === c.a);
    const bi = PORTS.findIndex((p) => p.name === c.b);
    if ((fromIdx === ai && toIdx === bi) || (fromIdx === bi && toIdx === ai)) return { ...c };
  }
  return null;
}

if (typeof module !== "undefined") module.exports = { PORTS };
